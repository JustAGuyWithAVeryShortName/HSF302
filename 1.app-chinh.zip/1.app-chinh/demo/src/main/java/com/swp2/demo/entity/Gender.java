package com.swp2.demo.entity;


public enum Gender {
    Male,
    Female,
}
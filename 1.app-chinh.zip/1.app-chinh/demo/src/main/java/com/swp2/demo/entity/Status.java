package com.swp2.demo.entity;

public enum Status {
    ONLINE,
    OFFLINE,
}
